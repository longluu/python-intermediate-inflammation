# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['inflammation']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.5.1,<4.0.0', 'numpy>=1.22.2,<2.0.0']

setup_kwargs = {
    'name': 'inflammation',
    'version': '1.0.0',
    'description': "Analyze patient's inflammation data",
    'long_description': None,
    'author': 'Long Luu',
    'author_email': 'thelong20.4@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
